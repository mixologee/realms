/**************************************************************************
 * * The Mythran Mud Economy Snippet Version 3 - updated for CircleMUD use!
 * *
 * * Copyrights and rules for using the economy system:
 * *
 * *      The Mythran Mud Economy system was written by The Maniac, it was
 * *      loosly based on the rather simple 'Ack!'s banking system'
 * *
 * *      If you use this code you must follow these rules.
 * *              -Keep all the credits in the code.
 * *              -Mail Maniac (v942346@si.hhs.nl) to say you use the code
 * *              -Send a bug report, if you find 'it'
 * *              -Credit me somewhere in your mud.
 * *              -Follow the envy/merc/diku license
 * *              -If you want to: send me some of your code
 * *
 * * All my snippets can be found on http://www.hhs.nl/~v942346/snippets.html
 * * Check it often because it's growing rapidly  -- Maniac --
 * *
 * **************************************************************************
 * *
 * * Version 3 represents a port to CircleMUD done by Edward Glamkowski.
 * * Earlier version were written for use with Envy MUD - please contact
 * * the Maniac with any questions concerning Envy MUD or the use of this
 * * code in that MUD base.  If you are using CircleMUD and have any 
 * * comments, questions or concerns, feel free to contact me at:
 * * eglamkowski@angelfire.com
 * *
 * * Please follow the above usage rules, and please also include me in
 * * your credits! =)
 * *
 * **************************************************************************/

#include "conf.h"
#include "sysdep.h"

#include "structs.h"
#include "utils.h"
#include "interpreter.h"
#include "comm.h"
#include "db.h"
#include "handler.h"
#include "economy.h"

//int share_value = SHARE_VALUE;      /* External share_value by Maniac */

struct blackmarket {

  int stock;
  int value;
};

struct blackmarket market_list[MAX_STOCK];

const char *livestock[] =
{
  "pigs",
  "cows",
  "horses",
  "dragoneggs",
  "mules",
  "chickens"
};

/* Local functions */
ACMD(do_bank);
ACMD(do_update);
void bank_update(void);

void load_bank(void);

/* Extern variables */
extern struct room_data *world;
extern struct time_info_data time_info;



ACMD(do_blackmarket)
{
 int amount = 0, stock=0, i, value=0;
 char say_buf[MAX_STRING_LENGTH], buf1[MAX_STRING_LENGTH];
 char buf2[MAX_STRING_LENGTH], arg[MAX_STRING_LENGTH];
 char buf3[MAX_STRING_LENGTH];


 if (!ROOM_FLAGGED(IN_ROOM(ch), ROOM_BLACKMARKET)) {
   /* Should never happen, but just in case... -ejg */
   send_to_char(ch, "You can't do that here.\r\n");
   return;
 }


 if (IS_NPC(ch)) {
   send_to_char(ch, "Banking Services are only available to players!\r\n");
   return;
 }


 if (!argument || !*argument) {
   send_to_char(ch, "Black Market Options:\r\n\r\n");
   send_to_char(ch, "Blackmarket buy <stock> #    : Buy # shares\r\n");
   send_to_char(ch, "Blackmarket sell <stock> #   : Sell # shares\r\n");
   send_to_char(ch, "Blackmarket shares           : Check how many shares you own\r\n");
   send_to_char(ch, "Blackmarket check            : Check the current rates of the shares.\r\n");
   return;
 }

 *say_buf = '\0';

 /* Yuck - this is a horrible hack, but we may need a third argument
 *   * if we are doing a transfer option... -ejg */
 half_chop(argument, buf1, arg);
 two_arguments(arg, buf2, buf3);


 /* Now work out what to do... */
 if (!str_cmp(buf1, "buy")) {

  if(*buf2) {
   for(i=0;i < MAX_STOCK;i++) {
     if(is_abbrev(livestock[i], buf2)) {
       stock = i;
       break;
     }
   }

   if (is_number(buf3)) {
     amount = atoi(buf3);
     value = (int) &market_list[stock].value;

    if ((amount * market_list[stock].value) > GET_BALANCE(ch)) {
	sprintf(say_buf, "'%d shares of %s will cost you "
		"%d gold, get more money!'\r\n", amount, livestock[stock],
		(amount * market_list[stock].value));
            send_to_char(ch, say_buf);
        send_to_char(ch, "%d %d %ld", amount, market_list[stock].value, GET_BALANCE(ch));
	return;
     }

     GET_BALANCE(ch) -= (amount * market_list[stock].value);
     GET_SHARES(ch, stock) += amount;
     send_to_char(ch, "'You buy %d shares of %s for %d gold, you now have %ld shares.'\r\n", 
             amount, livestock[i], (amount * (int) &market_list[stock].value), GET_SHARES(ch, stock));
     return;
   }
  }
 }

 if (!str_cmp(buf1, "sell")) {

  if(*buf2) {
   for(i=0;i < MAX_STOCK;i++) {
     if(is_abbrev(livestock[i], buf2)) {
       stock = i;
       break;
     }
   }

   if (is_number (buf3)) {
     amount = atoi(buf3);

     if (amount > GET_SHARES(ch, stock)) {
	sprintf(say_buf, "'You only have %ld shares!'\r\n", GET_SHARES(ch, stock));
	send_to_char(ch, say_buf);
	return;
    }

     GET_BALANCE(ch) += (amount * market_list[stock].value);
     GET_SHARES(ch, stock) -= amount;
     sprintf(say_buf, "You sell %d shares for %d gold, you now have %ld shares.\r\n",  amount,
	      (amount * market_list[stock].value), GET_SHARES(ch, stock));
     send_to_char(ch, say_buf);
     return;
   }
  }
 }

 if (!str_cmp(buf1, "shares")) {
   sprintf(say_buf, "You have %ld shares.'\r\n", GET_SHARES(ch, stock));
   send_to_char(ch, say_buf);
   return;
 }

 if (!str_cmp(buf1, "check")) {

   send_to_char(ch, "  Current Black Market Values\r\n"
                    "===============================\r\n"
                    " Commodity     Value    Shares\r\n"
                    "===============================\r\n");

  for(i=0;i<MAX_STOCK;i++)
     send_to_char(ch, "%10s %7d      %ld\r\n", livestock[i], market_list[i].value, GET_SHARES(ch, i));

   return;
 }

return;
}


ACMD(do_update)
{
 char arg[MAX_STRING_LENGTH];

 one_argument(argument, arg);

 if (!arg || !*arg) {
   send_to_char(ch, "Current options to update: \r\n\r\n");
   send_to_char(ch, "bank: Update the stock market ticker.\r\n");
   return;
 }
 
 if (!str_cmp(arg, "bank")) {
   bank_update();
   send_to_char(ch, "Ok...bank updated.\r\n");
 }
 /* Add new update options here */

 return;
}

		  
/*
* Update the bank system
* * (C) 1996 The Maniac from Mythran Mud
* *
* * This updates the shares value (I hope)
* *
* * (It does, but not in an interesting way!  
* *  To the IMP reading this: change it! -ejg)
* */
void bank_update(void)
{
 int   value = 0, i;
 FILE *fp;

// if ((time_info.hours > 17))
//   return;         /* Bank is closed, no market... */
 
   if (!(fp = fopen(BANK_FILE, "w"))) {
     log("bank_update:  Couldn't open file %s", BANK_FILE);
     return;
   }

  for(i=0;i<MAX_STOCK;i++) {

   value = rand_number(0, 200);
   value -= 100;
   value /= 10;
 
   market_list[i].value += value;
 
   fprintf(fp, "%d %d\r\n", market_list[i].stock, market_list[i].value );
  }

  fclose(fp);

return;
}


/*
* Load the bank information (economy info)
* * By Maniac from Mythran Mud
* *
* * Totally re-written by Ed Glamkowski, now includes error checking
* * and recovery.
* */


void load_bank(void)
{
 FILE *fp;
 int  number = 0, stock=0, i;

 if (!(fp = fopen(BANK_FILE, "r")))
   return;

 for(i = 0;i < MAX_STOCK;i++) {
  if (fscanf(fp, "%d %d", &stock, &number) != 2) {
    log("SYSERR:  Failed to load bank, using default value %d  %d", stock, number);
    number = SHARE_VALUE;
  }

  if (stock < 0) {
    log("SYSERR:  Error in bank file (encountered %d).  Using default value", stock);
    number = SHARE_VALUE;
  }
  market_list[i].stock = stock;
  market_list[i].value = number;
 }

 return;
}

