
/* ************************************************************************
*   File: weather.c                                                       *
*  Usage: functions handling time and the weather                         *
*                                                                         *
************************************************************************ */

#include "conf.h"
#include "sysdep.h"

#include "screen.h"
#include "structs.h"
#include "utils.h"
#include "comm.h"
#include "handler.h"
#include "interpreter.h"
#include "db.h"

extern struct time_info_data time_info;

void weather_and_time(int mode);
void another_hour(int mode);
void weather_change(void);
void check_fishing();
void fishing_message();
void get_lumber(struct char_data *ch);

void weather_and_time(int mode)
{
  another_hour(mode);
  if (mode)
    weather_change();
}


void another_hour(int mode)
{
  time_info.hours++;

  if (mode) {
    switch (time_info.hours) {
    case 5:
      weather_info.sunlight = SUN_RISE;
      send_to_outdoor("&YThe sun rises in the east.&n\r\n");
      break;
    case 6:
      weather_info.sunlight = SUN_LIGHT;
      send_to_outdoor("&gThe day has begun.&n\r\n");
      break;
    case 21:
      weather_info.sunlight = SUN_SET;
      send_to_outdoor("&mThe sun slowly disappears in the west.&n\r\n");
      break;
    case 22:
      weather_info.sunlight = SUN_DARK;
      send_to_outdoor("&bThe night has begun.&n\r\n");
      break;
    default:
      break;
    }
  }
  if (time_info.hours > 23) {	/* Changed by HHS due to bug ??? */
    time_info.hours -= 24;
    time_info.day++;

    if (time_info.day > 34) {
      time_info.day = 0;
      time_info.month++;

      if (time_info.month > 16) {
	time_info.month = 0;
	time_info.year++;
      }
    }
  }
}


void weather_change(void)
{
  int diff, change;
  if ((time_info.month >= 9) && (time_info.month <= 16))
    diff = (weather_info.pressure > 985 ? -2 : 2);
  else
    diff = (weather_info.pressure > 1015 ? -2 : 2);

  weather_info.change += (dice(1, 4) * diff + dice(2, 6) - dice(2, 6));

  weather_info.change = MIN(weather_info.change, 12);
  weather_info.change = MAX(weather_info.change, -12);

  weather_info.pressure += weather_info.change;

  weather_info.pressure = MIN(weather_info.pressure, 1040);
  weather_info.pressure = MAX(weather_info.pressure, 960);

  change = 0;

  switch (weather_info.sky) {
  case SKY_CLOUDLESS:
    if (weather_info.pressure < 990)
      change = 1;
    else if (weather_info.pressure < 1010)
      if (dice(1, 4) == 1)
	change = 1;
    break;
  case SKY_CLOUDY:
    if (weather_info.pressure < 970)
      change = 2;
    else if (weather_info.pressure < 990) {
      if (dice(1, 4) == 1)
	change = 2;
      else
	change = 0;
    } else if (weather_info.pressure > 1030)
      if (dice(1, 4) == 1)
	change = 3;

    break;
  case SKY_RAINING:
    if (weather_info.pressure < 970) {
      if (dice(1, 4) == 1)
	change = 4;
      else
	change = 0;
    } else if (weather_info.pressure > 1030)
      change = 5;
    else if (weather_info.pressure > 1010)
      if (dice(1, 4) == 1)
	change = 5;

    break;
  case SKY_LIGHTNING:
    if (weather_info.pressure > 1010)
      change = 6;
    else if (weather_info.pressure > 990)
      if (dice(1, 4) == 1)
	change = 6;

    break;
  default:
    change = 0;
    weather_info.sky = SKY_CLOUDLESS;
    break;
  }

  switch (change) {
  case 0:
    break;
  case 1:
    send_to_outdoor("&BThe sky starts to get cloudy.&n\r\n");
    weather_info.sky = SKY_CLOUDY;
    break;
  case 2:
    send_to_outdoor("&bIt starts to rain.&b\r\n");
    weather_info.sky = SKY_RAINING;
    break;
  case 3:
    send_to_outdoor("&WThe clouds disappear.&n\r\n");
    weather_info.sky = SKY_CLOUDLESS;
    break;
  case 4:
    send_to_outdoor("&YLightning starts to show in the sky.&n\r\n");
    weather_info.sky = SKY_LIGHTNING;
    break;
  case 5:
    send_to_outdoor("&gThe rain stops.&n\r\n");
    weather_info.sky = SKY_CLOUDY;
    break;
  case 6:
    send_to_outdoor("&YThe lightning stops.&n\r\n");
    weather_info.sky = SKY_RAINING;
    break;
  default:
    break;
  }
}

void check_fishing() {

  struct descriptor_data *d;
  int bite;

  for (d = descriptor_list; d; d = d->next) {
    if (d->connected) continue;
    if (IS_NPC(d->character)) continue;

    if (PLR_FLAGGED(d->character, PLR_FISHING) &&
      (!ROOM_FLAGGED(d->character->in_room, ROOM_SALTWATER_FISH) &&
       !ROOM_FLAGGED(d->character->in_room, ROOM_FRESHWATER_FISH) &&
       !ROOM_FLAGGED(d->character->in_room, ROOM_TREASUREWATER_FISH)))
      REMOVE_BIT_AR(PLR_FLAGS(d->character), PLR_FISHING);

    if (PLR_FLAGGED(d->character, PLR_FISHING) &&
       !PLR_FLAGGED(d->character, PLR_FISH_ON)) {

      bite = rand_number(1, 10);

      if (GET_LEVEL(d->character) > 40)
         bite = 2;

      if (bite >= 7 && bite <= 8) {
        send_to_char(d->character, "&GTime goes by... not even a nibble. Might wanna roll one up...&n\r\n");
      } else if (bite >= 6) {
       send_to_char(d->character, "&cYou feel a slight jiggle on your line.&n\r\n");
      } else if (bite >= 4) {
       send_to_char(d->character, "&CYou feel a very solid pull on your line!&n\r\n");
       SET_BIT_AR(PLR_FLAGS(d->character), PLR_FISH_ON);
      } else if (bite >= 2) {
       send_to_char(d->character, "&CYour line suddenly jumps to life, FISH ON!!!&n\r\n");
       SET_BIT_AR(PLR_FLAGS(d->character), PLR_FISH_ON);
      }
    }
  }
}

void fishing_message() {
                                                                                                 
  struct descriptor_data *d;
  int bite;
                                                                                                 
  for (d = descriptor_list; d; d = d->next) {
    if (d->connected) continue;
    if (IS_NPC(d->character)) continue;
                                                                                                 
    if (PLR_FLAGGED(d->character, PLR_FISHING) &&
      (!ROOM_FLAGGED(d->character->in_room, ROOM_SALTWATER_FISH) &&
       !ROOM_FLAGGED(d->character->in_room, ROOM_FRESHWATER_FISH) &&
       !ROOM_FLAGGED(d->character->in_room, ROOM_TREASUREWATER_FISH)))
      REMOVE_BIT_AR(PLR_FLAGS(d->character), PLR_FISHING);
                                                                                                 
    if (PLR_FLAGGED(d->character, PLR_FISHING))
    {
                                                                                                 
      bite = rand_number(1, 10);
                                                                                                 
      if (bite >= 7 && bite <= 8) {
        send_to_char(d->character, "&MA soft breeze from the water blows gently across your face.&n\r\n");
      } else if (bite >= 6) {
       send_to_char(d->character, "&MTiny bubbles ripple up from below the water.&n\r\n");
      } else if (bite >= 4) {
       send_to_char(d->character, "&MSmall water spiders run along top of the water!!&n\r\n");
      } else if (bite >= 2) {
       send_to_char(d->character, "&MFishing can get quite boring sometimes, maybe you should blaze one to help pass the time.&n\r\n");
      }
    }
  }
}

void check_lumber() {

  struct descriptor_data *d;
  int chop;

  for (d = descriptor_list; d; d = d->next) {
    if (d->connected) continue;
    if (IS_NPC(d->character)) continue;

    if (PLR_FLAGGED(d->character, PLR_LUMBER) && (ROOM_FLAGGED(IN_ROOM(d->character), SECT_JUNGLE) || ROOM_FLAGGED(IN_ROOM(d->character), SECT_JUNGLE) || ROOM_FLAGGED(IN_ROOM(d->character), SECT_JUNGLE)))
      REMOVE_BIT_AR(PLR_FLAGS(d->character), PLR_LUMBER);

    if (PLR_FLAGGED(d->character, PLR_LUMBER)) {

      chop = rand_number(1, 10);

      if (chop >= 7 && chop <= 8) {
        send_to_char(d->character, "&GTime goes by and you keep choppin' away.... &n\r\n");
      } else if (chop >= 6) {
       send_to_char(d->character, "&cYou see a few splinters fly from the tree.&n\r\n");
       GET_CHOP_TIME(d->character) -= 1;
      } else if (chop >= 4) {
       send_to_char(d->character, "&CYou feel like you are making good progress on this tree.&n\r\n");
       GET_CHOP_TIME(d->character) -= 2;
      } else if (chop >= 2) {
       send_to_char(d->character, "&CYou see a huge chunk of wood go flying from the trunk.&n\r\n");
       GET_CHOP_TIME(d->character) -= 2;
      }
    }

    if (PLR_FLAGGED(d->character, PLR_LUMBER) && GET_CHOP_TIME(d->character) < 1)
    {
         if (PLR_FLAGGED(d->character, PLR_LUMBER))
         {
          REMOVE_BIT_AR(PLR_FLAGS(d->character), PLR_LUMBER);
          get_lumber(d->character);
         }
    }
  }
}
