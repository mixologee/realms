
#include "conf.h"
#include "sysdep.h"

#include "structs.h"
#include "utils.h"
#include "comm.h"
#include "interpreter.h"
#include "handler.h"
#include "db.h"
#include "spells.h"
#include "house.h"
#include "screen.h"
#include "constants.h"
#include "oasis.h"
#include "warzone.h"
#include "clan.h"
#include "dg_scripts.h"
#include "arena.h"

ACMD(do_checkloadstatus);
ACMD(do_rain);
ACMD(do_gozone);
ACMD(do_dbs);
ACMD(do_godchan);
ACMD(do_gocoord);
ACMD(do_peace_all);
ACMD(do_finddoor);
ACMD(do_findkey);

extern void vwear_obj(int type, char_data * ch);
extern void vwear_object(int wearpos, char_data * ch);
void clearMemory(struct char_data *ch);

void do_mbind(struct char_data *ch, struct char_data *vict);


ACMD(do_rain) 
{                          
  struct descriptor_data *d;
  obj_data *object = NULL;
  char arg[MAX_STRING_LENGTH];
  char buf[MAX_STRING_LENGTH];
  obj_rnum obj_vnum, rnum;

  one_argument(argument, arg);



/*
bool found = FALSE;
char arg[MAX_STRING_LENGTH];
int i=0;

one_argument(argument, arg);


  for (i=0 ; rain_items[i].name != '\n' ; i++) {
    if (rain_items[i].name == LOWER(arg)) {
      found = TRUE;
      break;


struct rain_items {
    char    *name;            
    int     level;      
    int     vnum;
    bool    disabled;     
};


rain_items[] = {
                   { "greenorb"  ,           LVL_GOD  ,  2118,	-1},  // 0
                   { "smallgold" ,           LVL_GOD  ,     2,	 1},
                   { "biggold"   ,           LVL_IMPL ,  NULL,	 1},
                   { "potion"    ,           LVL_GOD  ,  7263,	 1},
                   { "\n"        ,                 0  ,  NULL,	-1}
                };

*/


if (!*arg) {
    send_to_char(ch, "\r\nSyntax: rain <vnumber>\r\n"            
                   "Use vnum o <objtype> to find what you want to rain");
    return;       
  }                     

  if ((obj_vnum = atoi(arg)) < 0) {
    send_to_char(ch, "\r\nPlease specify a number that is not negative!\r\n");
    return;        
  }           

  if ((rnum = real_object(obj_vnum)) < 0) {
    send_to_char(ch, "\r\nThere is no object with that number.\r\n");
    return;      
  }              

  for (d = descriptor_list ; d ; d = d->next) {
    if (!d->connected && d->character && d->character != ch) {
      if (GET_LEVEL(d->character) >= LVL_IMM)
        continue;
      else {                      
        object = read_object(rnum, REAL);
        obj_to_room(object, d->character->in_room);
        act("&WHappy Days, the gods of Kuvia have rained the lands "
            "with $p, to aid you in your quest.",
            FALSE, d->character, object, 0, TO_CHAR);
      }
    }
  }
  if (object) {
    act("You rain $p over the world.", FALSE, ch, object, 0, TO_CHAR);
    sprintf(buf, "It starts raining %s, thanks to the goodness of %s", object->short_description, GET_NAME(ch));
    mudlog(BRF, LVL_GOD, TRUE, "GOD RAIN: %s rained %s", GET_NAME(ch), object->short_description);
  } else
    act("There are no mortals to receive your gifts.", FALSE, ch, 0, 0, TO_CHAR);
}

ACMD(do_gozone)            
{
room_rnum location = NOWHERE;
  zone_rnum zone = 0;       
  bool found = FALSE;         
  char arg[MAX_STRING_LENGTH];
  char buf[MAX_STRING_LENGTH];

  one_argument(argument, arg);


  if (!*arg) {    
    send_to_char(ch,"Syntax: gozone <zone number>\n\r");
    return;
  }                      

  if (!isdigit(*arg)) {
     send_to_char(ch, "You must give a number.\n\r");
    return;    
  }             

  if ((location = atoi(arg)) < 0) {
    send_to_char(ch, "All zone numbers are positive!\n\r");
    return;
  }                

  for ( ; zone <= top_of_zone_table ; zone++) {
    if (zone_table[zone].number == location) {
      found = TRUE;
      break;  
    }         
  }

  if (!found) {
    send_to_char(ch, "That zone could not be found. Use SHOW ZONE to "
              "find the correct number.\n\r");
    return;
  }

  for (location = zone_table[zone].bot ; location <= zone_table[zone].top ; location++) {
    if (real_room(location) != NOWHERE)
      break;
  }

  if ((location = real_room(location)) == NOWHERE) {
    send_to_char(ch, "The beginning room of the zone does not seem to exist!\n\r");
    return;
  }

  if (POOFOUT(ch))
    sprintf(buf, "%s&n", POOFOUT(ch));
  else
    sprintf(buf, "&R$n disappears in a puff of smoke.&n");

  act(buf, TRUE, ch, 0, 0, TO_ROOM);
  char_from_room(ch);
  char_to_room(ch, location);

  if (POOFIN(ch))
    sprintf(buf, "%s&n", POOFIN(ch));
  else
    sprintf(buf, "&R$n appears with an ear-splitting bang.&n");


  act(buf, TRUE, ch, 0, 0, TO_ROOM);
  look_at_room(ch, 0);
}


ACMD(do_peace_all)   
{                
  struct descriptor_data *d; 

  act("$n has declared world peace, for now!", FALSE, ch, 0, 0, TO_ROOM);
  send_to_room(IN_ROOM(ch), "The world is at peace.\r\n");
  for (d = descriptor_list; d; d = d->next) {
      if (FIGHTING(d->character))
        stop_fighting(d->character);
      if (IS_NPC(d->character)) 
        stop_fighting(d->character);
        clearMemory(d->character);
  }
}

 

ACMD(do_dbs)
{
 // use apply_types for hps etc, 

  char syntax[MAX_STRING_LENGTH];
  char buf[MAX_STRING_LENGTH];
  int found = 0, linect = 0;
  int apply = 1;
  int i, nr, k;

  sprintf(syntax, "&BSyntax: &Cdbs <affect>&n\n\r&WWhere affect is one of the following:&c\n\r");
//  for (i = 1; i <= MAX_OBJ_AFFECT; i++) {
  for (i = 1; i <= 24; i++) {
    if (strstr(apply_types[i], "UNUSED"))
      continue;

    if (linect!= 0 && ((linect) % 3) == 0)
      sprintf(syntax, "%s\n\r", syntax);

    sprintf(syntax, "%s %-7s", syntax, apply_types_small[i]);
    linect++;
  }
  sprintf(syntax, "%s\n\r", syntax);

  if (!*argument) {
    send_to_char(ch,"&c%s",syntax);
    return;
  }

  skip_spaces(&argument);

//  for (; apply <= MAX_OBJ_AFFECT; apply++) {
  for (; apply <= 24; apply++) {
    if (is_abbrev(argument, apply_types_small[apply])) {
      found = 1;
      break;
    }
  }

  if (!found) {
    send_to_char(ch,"%s", syntax);
    return;
  }


  sprintf(buf, "\r\n&WLooking for objects with the &R%s &Waffect:"
               "\r\n&c-------------------------------------------------------"
               "\r\n&C  #     vnum      +/-      name"
               "\r\n&c-------------------------------------------------------&n\r\n",apply_types[apply]);

  for (nr = 0; nr <= top_of_objt; nr++) {
    for (k=0;k<=24;k++){
//    for (k = 0; k < MAX_OBJ_AFFECT; k++) {
      if (obj_proto[nr].affected[k].location == apply)
        sprintf(buf, "%s&W%3d. &c[&C%6ld&c] &W- &g(&G%4d&g)   &m%s&n\n\r", buf, found++, obj_index[nr].vnum,
                obj_proto[nr].affected[k].modifier, obj_proto[nr].short_description);
    }
  }
  page_string(ch->desc, buf, 1);
}    


ACMD(do_godchan)
{             
  struct descriptor_data *d;                     
  char chanbuf[MAX_INPUT_LENGTH], chanbuf1[MAX_INPUT_LENGTH];           
  char buf1[MAX_STRING_LENGTH];
  char prefix[20];
  int level = 0, emote = FALSE, potato=0;

  skip_spaces(&argument);
  delete_doubledollar(argument);

  if (!*argument) {
    send_to_char(ch, "Say what?\r\n");
    return;
  }

  switch (*argument) {
  case '*':
    emote = TRUE;
  case '#':
    one_argument(argument + 1, buf1);
    if (is_number(buf1)) {
      half_chop(argument + 1, buf1, argument);
      level = MAX(atoi(buf1), LVL_IMMORT);
      if (level > GET_LEVEL(ch)) {
        send_to_char(ch, "You can't use an immortal channel above your own level.\r\n");      
        return;
      }
    } else if (emote)
      argument++;
    break;
  default:
    break;
  }
  switch (subcmd) {
  case SCMD_IMPL:
    sprintf(chanbuf, "&nImplementors&R [%s]: &n%s\r\n", GET_NAME(ch), argument);
    sprintf(chanbuf1, "%s", chanbuf);
    level = LVL_IMPL;
    potato = PRF_NOWIZ;
//    add_history(d->character, chanbuf, HIST_IMPL);
    break;
  case SCMD_GRGOD:
    sprintf(chanbuf, "&MGrGods&R [%s]:&n %s\r\n", GET_NAME(ch), argument);
    sprintf(chanbuf1, "%s", chanbuf);
    level = LVL_GRGOD;
    potato = PRF_NOWIZ;
//    add_history(d->character, chanbuf, HIST_GRGOD);
    break;
  case SCMD_GOD:
    sprintf(chanbuf, "&gGod &R[%s]: &n%s\r\n", GET_NAME(ch), argument);
    sprintf(chanbuf1, "%s", chanbuf);
    level = LVL_GOD;
    potato = PRF_NOWIZ;
//    add_history(d->character, chanbuf, HIST_GOD);
    break;
  case SCMD_WIZNET:
    sprintf(chanbuf, "&CWiznet &R[%s]: &n%s\r\n", GET_NAME(ch), argument);
    level = LVL_IMMORT;
    potato = PRF_NOWIZ;
//    add_history(d->character, chanbuf, HIST_WIZNET);
    break;            
  case SCMD_PRECEPTORCHAN:
    if (PLR_FLAGGED(ch, PLR_PRECEPTOR)) {
    sprintf(chanbuf, "&YPreceptor &R[%s]: &n%s\r\n", GET_NAME(ch), argument);
    level = LVL_IMMORT;
    potato = PRF2_NOPRECEPTOR;
//    add_history(d->character, chanbuf, HIST_PREC);
    break;
    }
    break;
  case SCMD_IMMORT:
    *prefix = '\0';

    if (GET_LEVEL(ch) >= LVL_IMMORT)   
      sprintf(prefix, "&G");

    if (GET_LEVEL(ch) > LVL_IMMORT && !level) {
      sprintf(chanbuf, "%s%s(%d) &C:: %s%s\r\n", prefix, GET_NAME(ch),GET_LEVEL(ch),  emote ? "<--- " : "", argument);
      sprintf(chanbuf1,"&CSomeone :: %s%s\r\n",  emote ? "<--- " : "", argument);
    } else if (GET_LEVEL(ch) > LVL_IMMORT && level) {
      sprintf(chanbuf, "%s%s(%d) &C:: %s%s\r\n", prefix, GET_NAME(ch), level, emote ? "<--- " : "", argument);
      sprintf(chanbuf1,"&CSomeone :: %s%s\r\n", emote ? "<--- " : "", argument);
    } else {     
      sprintf(chanbuf, "%s%s&C :: %s%s\r\n", prefix, GET_NAME(ch), emote ? "<--- " : "", argument);
      sprintf(chanbuf1,"&CSomeone :: %s%s\r\n", emote ? "<--- " : "", argument);
    }     
    potato = PRF_NOWIZ;
//    add_history(d->character, chanbuf, HIST_WIZNET);
    break;         
  default:
    send_to_char(ch, "&RERROR in do_channel, please report to Slurk with reference to do_channel error.&n\r\n");
    return;         
    break;             
  }

  for (d = descriptor_list; d; d = d->next) {
    if (IS_PLAYING(d) && (GET_LEVEL(d->character) >= LVL_IMMORT) &&           
        (!PRF_FLAGGED(d->character, potato)) &&
        (!(PRF_FLAGGED(d->character, PRF_NOREPEAT)))) {
        
//      if (CAN_SEE(d->character, ch))
        send_to_char(d->character, chanbuf);
//      else
//        send_to_char(d->character, chanbuf1);
    }
  }
}


ACMD(do_vwear)
{
  int i, j;
  char buf[MAX_STRING_LENGTH];
  char arg[MAX_STRING_LENGTH];

  struct virtual_wear_location {
    const char *loc;
    void (*pointer) (int pos, char_data *ch);
    int pos;
  }
  fields[] = {
               { "finger"    , vwear_object, ITEM_WEAR_FINGER },
               { "neck"      , vwear_object, ITEM_WEAR_NECK },
               { "body"      , vwear_object, ITEM_WEAR_BODY },
               { "head"      , vwear_object, ITEM_WEAR_HEAD },
               { "legs"      , vwear_object, ITEM_WEAR_LEGS },
               { "feet"      , vwear_object, ITEM_WEAR_FEET },
               { "hands"     , vwear_object, ITEM_WEAR_HANDS },
               { "arms"      , vwear_object, ITEM_WEAR_ARMS },
               { "shield"    , vwear_object, ITEM_WEAR_SHIELD },
               { "about"     , vwear_object, ITEM_WEAR_ABOUT },
               { "waist"     , vwear_object, ITEM_WEAR_WAIST },
               { "wrist"     , vwear_object, ITEM_WEAR_WRIST },
               { "wield"     , vwear_object, ITEM_WEAR_WIELD },
               { "held"      , vwear_object, ITEM_WEAR_HOLD },
               { "aura"      , vwear_object, ITEM_WEAR_AURA },
               { "light"     , vwear_obj   , ITEM_LIGHT },
               { "scroll"    , vwear_obj   , ITEM_SCROLL },
               { "wand"      , vwear_obj   , ITEM_WAND },
               { "staff"     , vwear_obj   , ITEM_STAFF },
               { "weapon"    , vwear_obj   , ITEM_WEAPON },
               { "fireweapon", vwear_obj   , ITEM_FIREWEAPON },
               { "crygate"   , vwear_obj   , ITEM_CRYGATE },
               { "treasure"  , vwear_obj   , ITEM_TREASURE },
               { "armor"    , vwear_obj   , ITEM_ARMOR },
               { "potion"    , vwear_obj   , ITEM_POTION },
               { "worn"      , vwear_obj   , ITEM_WORN },
               { "other"     , vwear_obj   , ITEM_OTHER },
               { "trash"     , vwear_obj   , ITEM_TRASH },
               { "trap"      , vwear_obj   , ITEM_TRAP },
               { "container" , vwear_obj   , ITEM_CONTAINER },
               { "note"      , vwear_obj   , ITEM_NOTE },
               { "drinkcontainer", vwear_obj, ITEM_DRINKCON },
               { "key"       , vwear_obj   , ITEM_KEY },
               { "food"      , vwear_obj   , ITEM_FOOD },
               { "money"     , vwear_obj   , ITEM_MONEY },
               { "pen"       , vwear_obj   , ITEM_PEN },
               { "boat"      , vwear_obj   , ITEM_BOAT },
               { "fountain"  , vwear_obj   , ITEM_FOUNTAIN },
               { "pole",    vwear_obj , ITEM_POLE },
               { "bow"       , vwear_obj   , ITEM_BOW },
               { "sling"      , vwear_obj   , ITEM_SLING },
               { "crossbow", vwear_obj , ITEM_CROSSBOW },
               { "bolt"       , vwear_obj , ITEM_BOLT },
               { "arrow"     , vwear_obj , ITEM_ARROW },
               { "rock"       , vwear_obj , ITEM_ROCK },
               { "crumblekey", vwear_obj , ITEM_CRUM_KEY },
               { "comp"      , vwear_obj , ITEM_COMP },
               { "autoquest", vwear_obj , ITEM_AUTOQUEST },
               { "throw"      , vwear_obj , ITEM_THROW },
               { "furniture"  , vwear_obj , ITEM_FURNITURE },
               { "\n"        , NULL        , 0 }
             };

  one_argument(argument, arg);

  if (!*arg) {
    strcpy(buf, "Syntax: vwear <type>\r\n");
    strcat(buf, "\r\nItem types:\r\n");
    for (j = 0, i = 0 ; strcmp(fields[i].loc, "\n") ; i++) {
      sprintf(buf, "%s%-15s%s", buf, fields[i].loc,
              (!(++j % 5) ? "\r\n" : ""));
    }
    if ((j % 5))
      strcat(buf, "\r\n");
    send_to_char(ch, buf);
    return;
  }

  for (i = 0 ; *(fields[i].loc) != '\n' ; i++) {
    if (!strncmp(arg, fields[i].loc, strlen(arg)))
      break;
  }

  if (!strcmp(fields[i].loc, "\n")) {
    send_to_char(ch, "That is not an option.\r\n");
    return;
  } else
    ((*fields[i].pointer)(fields[i].pos, ch));
}


ACMD(do_gocoord)      
{
  int room, x, y; 
  int maxX, maxY;
  maxX = maxY = 1999;
  char arg[MAX_STRING_LENGTH];
  char buf[MAX_STRING_LENGTH];

  half_chop(argument, arg, buf);

  if (!*arg || !*buf) {
    send_to_char(ch,"Syntax: gocoord <X> <Y>\r\n");
    return;            
  }

  if (!isdigit(*arg) || !isdigit(*buf)) {
    send_to_char(ch, "Only digits are coordinates!\r\n\rSyntax: gocoord <X> <Y>\r\n");
    return;
  }

  if (atoi(arg) >= maxX || atoi(buf) >= maxY) {
    send_to_char(ch, "Max coordinates are 1999x1999\r\n");
    return;
  }

  x = atoi(arg);
  y = atoi(buf);


  room = MAPZONE + (y * MAPY) + x;

  if (real_room(room) < 0) {
    send_to_char(ch, "Coordinates X:%d Y:%d does not exist!\r\n", x, y);
    return;     
  }

  char_from_room(ch);
  char_to_room(ch, real_room(room));
  look_at_room(ch, 0);
}


ACMD(do_unbind)
{
  char obj_name[MAX_INPUT_LENGTH];
  struct obj_data *obj;

  one_argument(argument, obj_name);

  if (!*obj_name) {
    send_to_char(ch, "Usage: unbind <obj_name>\r\nYou must be carrying this object to unbind it.\r\n");
    return;
  }

  if ((obj = get_obj_in_list_vis(ch, obj_name, NULL, ch->carrying)) == NULL) {
    send_to_char(ch, "You are not carrying a %s.\r\n", obj_name);
    return;
  }

  /*
  if (!(obj = get_obj_in_list_vis(ch, obj_name, NULL, ch->carrying))) {
    send_to_char(ch, "You are not carrying a %s.\r\n", obj_name);
    return;
  }
  */
  if (GET_OBJ_BOUND_ID(obj) == NOBODY) {
    send_to_char(ch, "&CThe &R%s &Cis not bound to anybody.&n\r\n", obj->short_description);
    return;
  }

  if (get_name_by_id(GET_OBJ_BOUND_ID(obj)) == NULL) {
    send_to_char(ch, "The person the object was bound to has deleted, this item has been unbound!\r\n");
    GET_OBJ_BOUND_ID(obj) = NOBODY;
    return;
  }

  sprintf(obj_name, "%s", obj->short_description);
  
  send_to_char(ch, "&Y%s&C was bound to &Y%s&n\r\n", CAP(obj_name), get_name_by_id(GET_OBJ_BOUND_ID(obj)));
  send_to_char(ch, "&RThis item has now been unbound!\r\n");
  GET_OBJ_BOUND_ID(obj) = NOBODY;
  mudlog(CMP, MAX(LVL_GOD, GET_INVIS_LEV(ch)), TRUE, "&R(GC) %s used the unbind command on %s", GET_NAME(ch), obj->short_description);
}


void do_mbind(struct char_data *ch, struct char_data *vict)
{
  if (IS_NPC(vict) && !IS_NPC(ch)) 
    GET_MOB_BOUND_ID(vict) = GET_IDNUM(ch);  
  else
    return;
}


ACMD(do_bind)
{

  char char_name[MAX_INPUT_LENGTH], obj_name[MAX_INPUT_LENGTH];
  struct obj_data *obj;
  struct char_data *vict;

  two_arguments(argument, obj_name, char_name);

  if (!*obj_name) {
    send_to_char(ch, "Usage: bind <obj> <name>\r\nYou must have this obj in your inventory to bind it.\r\n");
    return;
  }

  if (!(obj = get_obj_in_list_vis(ch, obj_name, NULL, ch->carrying))) {
    send_to_char(ch, "You are not carrying %s %s.\r\n",AN(obj_name), obj_name);
    return;
  }

  if (!*char_name) {
    send_to_char(ch, "To whom would you like to bind %s?\r\n", obj->short_description);
    return;
  }

  if (!(vict = get_char_vis(ch, char_name, NULL, FIND_CHAR_WORLD))) {
    send_to_char(ch, "No one by that name currently logged in.\r\n");
    return;
  }

  if (GET_OBJ_BOUND_ID(obj) != NOBODY) {
    if (GET_OBJ_BOUND_ID(obj) == GET_IDNUM(vict)) {
      send_to_char(ch, "&CIt is already bound to &Y%s&n\r\n", GET_NAME(vict));
      return;
    }
    else {
      send_to_char(ch, "&CIt is currently bound to &Y%s&C. Unbind it first!&n\r\n", get_name_by_id(GET_OBJ_BOUND_ID(obj)));
      return;
    }
  }
  GET_OBJ_BOUND_ID(obj) = GET_IDNUM(vict);
  send_to_char(ch, "&Y%s &Cis now bound to &Y%s&C.&n", obj->short_description, GET_NAME(vict));
  mudlog(CMP, MAX(LVL_GOD, GET_INVIS_LEV(ch)), TRUE, "&R(GC) %s used the bind command on %s, binding it to %s", 
GET_NAME(ch), obj->short_description, get_name_by_id(GET_OBJ_BOUND_ID(obj)));
}


ACMD(do_barrier)
{
  struct room_affect *raff;
  char buf[MAX_INPUT_LENGTH];
  
  one_argument(argument, buf);

  if (!*buf) {
    send_to_char(ch, "Syntax: barrier <npc> | <pc>\r\n");
    return;
  }
  
  if (strcmp(buf, "npc")) {
  
    CREATE(raff, struct room_affect, 1);
     raff->type = RAFF_NPC_BARRIER;
     raff->timer = 10;
     raff->value = 0;
     raff->ch = NULL;
     raff->text = NULL;
     raff->room = IN_ROOM(ch); 
     raff->next = world[IN_ROOM(ch)].room_affs;
     world[IN_ROOM(ch)].room_affs = raff;
   }
   
   else if (strcmp(buf, "pc"))  {
    
    CREATE(raff, struct room_affect, 1);
     raff->type = RAFF_PC_BARRIER;
     raff->timer = 10;
     raff->value = 0;
     raff->ch = NULL;
     raff->text = NULL;
     raff->room = IN_ROOM(ch);
     raff->next = world[IN_ROOM(ch)].room_affs;
     world[IN_ROOM(ch)].room_affs = raff;
   }  
   else
     send_to_char(ch, "Syntax: barrier <npc> | <pc>\r\n");

}

ACMD(do_finddoor)
{
  int d, vnum = NOTHING, num = 0;
  size_t len, nlen;
  room_rnum i;
  char arg[MAX_INPUT_LENGTH];
  char buf[MAX_STRING_LENGTH] = {0};
  struct char_data *tmp_char;
  struct obj_data *obj;

  one_argument(argument, arg);

  if (!*arg) {
    send_to_char(ch, "Format: finddoor <obj/vnum>\r\n");
  } else if (is_number(arg)) {
    vnum = atoi(arg);
    obj = &obj_proto[real_object(vnum)];
  } else {
    generic_find(arg,
         FIND_OBJ_INV | FIND_OBJ_ROOM | FIND_OBJ_WORLD | FIND_OBJ_EQUIP,
         ch, &tmp_char, &obj);
    if (!obj)
      send_to_char(ch, "What key do you want to find a door for?\r\n");
    else
      vnum = GET_OBJ_VNUM(obj);
  }
  if (vnum != NOTHING) {
    if (GET_OBJ_TYPE(obj) != ITEM_KEY)
      send_to_char(ch, "It seems that %s isn't a key.\r\n", GET_OBJ_SHORT(obj));
    else {
      len = snprintf(buf, sizeof(buf), "Doors unlocked by key [%d] %s are:\r\n",
                      vnum, GET_OBJ_SHORT(obj));
      for (i = 0; i <= top_of_world; i++) {
        for (d = 0; d < NUM_OF_DIRS; d++) {
          if (world[i].dir_option[d] && world[i].dir_option[d]->key &&
              world[i].dir_option[d]->key == vnum) {
            nlen = snprintf(buf + len, sizeof(buf) - len,
                            "[%3d] Room %ld, %s (%s)\r\n",
                            ++num, world[i].number,
                            dirs[d], world[i].dir_option[d]->keyword);
            if (len + nlen >= sizeof(buf) || nlen < 0)
              break;
            len += nlen;
          }
        } /* for all directions */
      } /* for all rooms */
      if (num > 0)
        page_string(ch->desc, buf, 1);
      else
        send_to_char(ch, "No doors were found for key [%d] %s.\r\n",
                         vnum, GET_OBJ_SHORT(obj));
    }
  }
} 

ACMD(do_findkey)
{
  int dir, key;
  char arg[MAX_INPUT_LENGTH];
  char buf[MAX_STRING_LENGTH];

  any_one_arg(argument, arg); /* Because "in" is a valid direction */

  if (!*arg) {
    send_to_char(ch, "Format: findkey <dir>\r\n");
  } else if ((dir = search_block(arg, dirs, FALSE)) >= 0) { 
 //   || (dir = search_block(arg, abbr_dirs, FALSE)) >= 0 ) {
    if (!EXIT(ch, dir)) {
      send_to_char(ch, "There's no exit in that direction!\r\n");
    } else if ((key = EXIT(ch, dir)->key) == NOTHING || key == 0) {
      send_to_char(ch, "There's no key for that exit.\r\n");
    } else {
      sprintf(buf, "obj %d", key);
      do_checkloadstatus(ch, buf, 0, 0);
    }
  } else {
    send_to_char(ch, "What direction is that?!?\r\n");
  }
} 
