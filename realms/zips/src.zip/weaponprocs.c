
#include "conf.h"
#include "sysdep.h"

#include "structs.h"
#include "utils.h"
#include "comm.h"
#include "interpreter.h"
#include "handler.h"
#include "db.h"
#include "spells.h"
#include "house.h"
#include "screen.h"
#include "constants.h"
#include "oasis.h"
#include "warzone.h"
#include "clan.h"
#include "dg_scripts.h"
#include "arena.h"
#include "crystalgate.h"

void DoEquipmentProc(struct char_data *ch, struct char_data *vict)
{
  int DamAmnt, Duration, Dam, Dice;
  Dam = Duration = 0;
  extern struct index_data *obj_index;
  struct affected_type af;
 
  if (GET_EQ(ch, WEAR_HEAD) && GET_OBJ_VNUM(GET_EQ(ch, WEAR_HEAD)) == 6897) {
    DamAmnt = dice(12,8);
    Dice = dice(10,3);
    Duration = rand_number(15,20);

    if (DamAmnt >= 60 ) {
      if (Dice <= 20) {
        act("&mA wave of energy emerges from the eye pounding $n!", FALSE, vict, 0, 0, TO_ROOM);
        act("&mA wave of energy emerges from the eye pounding you hard!", FALSE, vict, 0, 0, TO_VICT);
        DamAmnt = rand_number(40, 60);
      }                 
      if (Dice >= 21) {
        act("&WA bright light flashes from within the eye blinding $n!", FALSE, vict, 0, 0, TO_ROOM);
        act("&WA bright light flashes from within the eye blinding you!", FALSE, vict, 0, 0, TO_VICT);
        DamAmnt = 0;

       af.type = SPELL_BLINDNESS;
       af.modifier = 0;
       af.location = 0;
       af.duration = Duration;
       af.bitvector = AFF_BLIND;
       affect_from_char(vict, SPELL_BLINDNESS);
       affect_to_char(vict, &af);
      }                 

      GET_HIT(vict) -= DamAmnt;
    }
  }

// add new If statements here for equipment

} // This is the closing bracket!!
  


void DoWeaponProc(struct char_data *ch, struct char_data *vict)
{
  int DamAmnt, Dam, Dice;
  Dam = 0;
  extern struct index_data *obj_index;

  if  (GET_EQ(ch, WEAR_WIELD) && GET_OBJ_VNUM(GET_EQ(ch, WEAR_WIELD)) == 6898) {
    DamAmnt = dice(10,9);
    Dice = dice(10, 3);
  
    if (DamAmnt >= 60) {
      if (Dice <= 20) { 
        act("&BBolts of electricity appear from the dagger striking $n!", FALSE, vict, 0, 0, TO_ROOM);
        act("&BBolts of electricity appear from the dagger striking you!", FALSE, vict, 0, 0, TO_VICT);
      }
      if (Dice >= 21) {
        act("&RWaves of fire spew forth from the dagger engulfing $n in flames!", FALSE, vict, 0, 0, TO_ROOM);
        act("&RWaves of fire spew forth from the dagger engulfing you in flames!", FALSE, vict, 0, 0, TO_VICT);
      }
    
      GET_HIT(vict) -= DamAmnt;
    } 
  }
// add new If statements here for weapons


} // This is closing bracket, add new after last bracket above this.


